<script setup lang="ts">
const showPassword = ref(false);

const { modelValue, className, placeholder, required, disabled } = defineProps({
  modelValue: { type: String, default: '' },
  className: { type: String, default: '' },
  placeholder: { type: String, default: '' },
  autocomplete: { type: String, default: 'new-password' },
  required: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['update:modelValue']);

const handleInputChanged = (e: Event) => {
  const target = e.target as HTMLInputElement;
  emit('update:modelValue', target.value);
};
</script>

<template>
  <div class="relative flex items-center w-full">
    <input
      :type="showPassword ? 'text' : 'password'"
      class="flex items-center flex-1"
      :value="modelValue"
      :class="className"
      :placeholder="placeholder"
      :autocomplete="autocomplete"
      :disabled="disabled"
      :required="required"
      @input="handleInputChanged" />
    <Icon v-if="showPassword" name="ion:eye-outline" size="20" class="absolute cursor-pointer right-4" @click="showPassword = !showPassword" />
    <Icon v-else name="ion:eye-off-outline" size="20" class="absolute cursor-pointer right-4" @click="showPassword = !showPassword" />
  </div>
</template>

<style scoped>
@reference "#tailwind";

input {
  @apply bg-gray-50 border border-gray-300 rounded-md shadow-inner outline-hidden w-full py-2 px-4 text-base leading-6 text-gray-900;
}
</style>
