<script setup lang="ts">
const { getFilter, setFilter, isFiltersActive } = useFiltering();

const { attribute } = defineProps({
  attribute: { type: Object, required: true },
});

const selectedTerms = ref(getFilter(attribute.slug) || []);
const filterTitle = ref(attribute.label || attribute.slug);
const isOpen = ref(attribute.openByDefault);

const isValidColorValue = (value?: string) => {
  const color = value?.trim();
  if (!color) return false;

  if (import.meta.client && window.CSS) {
    return CSS.supports('color', color);
  }

  return /^#(?:[0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(color);
};

const swatchStyle = (color?: string) => {
  return isValidColorValue(color) ? { '--color': color } : {};
};

watch(isFiltersActive, () => {
  // uncheck all checkboxes when filters are cleared
  if (!isFiltersActive.value) selectedTerms.value = [];
});

// Update the URL when the checkbox is changed
const checkboxChanged = () => {
  setFilter(attribute.slug, selectedTerms.value);
};
</script>

<template>
  <div class="cursor-pointer flex font-semibold pt-8 pb-4 leading-none justify-between items-center text-gray-900" @click="isOpen = !isOpen">
    <span>{{ filterTitle }}</span>
    <Icon name="ion:chevron-down-outline" class="transform text-gray-600" :class="isOpen ? 'rotate-180' : ''" />
  </div>
  <div v-show="isOpen" class="mr-6 max-h-60 grid gap-1.5 swatches overflow-auto custom-scrollbar">
    <div v-for="color in attribute.terms" :key="color.slug" :style="swatchStyle(color.slug)" :title="color.name">
      <input :id="color.slug" v-model="selectedTerms" class="hidden" type="checkbox" :value="color.slug" @change="checkboxChanged" />
      <label :for="color.slug" class="cursor-pointer m-0"></label>
    </div>
  </div>
</template>

<style scoped>
@reference "#tailwind";

.swatches {
  grid-template-columns: repeat(auto-fill, minmax(24px, 1fr));
}

.swatches label {
  @apply rounded-md cursor-pointer shadow-xs m-0 mb-1 w-full block relative;
  background-color: var(--color, white);
  filter: saturate(0.75);
  aspect-ratio: 1/1;
  transition: all 0.2s ease;
}

.swatches label:hover,
.swatches input:checked + label {
  filter: saturate(1);
}

/* tick */
.swatches input:checked + label::after {
  content: '';
  width: 25%;
  height: 40%;
  border-right: 2.5px solid #fff;
  border-bottom: 2.5px solid #fff;
  position: absolute;
  top: 45%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(45deg);
}

/* Make tick black if the color is white */
.swatches input:checked + label[for='white']::after,
.swatches input:checked + label[for='yellow']::after {
  border-color: #666;
}
</style>
