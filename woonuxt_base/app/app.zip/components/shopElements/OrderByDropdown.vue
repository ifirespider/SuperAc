<script setup>
const { getOrderQuery, setOrderQuery } = await useSorting();
const { storeSettings } = useAppConfig();
const selectedOrder = ref(getOrderQuery());
const orderby = ref(selectedOrder.value.orderBy || 'date');
const order = ref(selectedOrder.value.order);

// Update the URL when the checkbox is changed
watch([orderby, order], () => {
  setOrderQuery(orderby.value, order.value);
});
</script>

<template>
  <div class="inline-flex ml-auto -space-x-px shadow-xs rounded-md isolate">
    <button
      class="relative inline-flex items-center p-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-l-md hover:bg-gray-50 focus:z-20"
      aria-label="Sort"
      @click="order = order === 'ASC' ? 'DESC' : 'ASC'">
      <Icon name="ion:filter-outline" size="18" :class="order === 'ASC' ? 'rotate-180' : ''" class="transition-transform transform transform-origin-center" />
    </button>
    <select
      v-model="orderby"
      name="orderby"
      class="select bg-white border border-gray-300 rounded-l-none! border-l-0 text-sm leading-5 py-1.5"
      aria-label="Order by">
      <option value="date">{{ $t('general.latest') }}</option>
      <option value="alphabetically">{{ $t('general.alphabetically') }}</option>
      <option value="price">{{ $t('shop.price') }}</option>
      <option v-if="storeSettings.showReviews" value="rating">{{ $t('shop.rating') }}</option>
      <option value="discount">{{ $t('shop.discount') }}</option>
    </select>
  </div>
</template>
