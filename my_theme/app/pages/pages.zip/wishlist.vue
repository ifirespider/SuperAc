<template>
  <WishList />
</template>
