<template>
  <div>
    <!-- Page Header -->
    <div class="mb-8">
      <h1 class="text-3xl font-bold text-gray-900 mb-2">Password</h1>
      <p class="text-gray-600">Update your password to keep your account secure</p>
    </div>

    <form class="bg-white rounded-lg shadow-xs border border-gray-100 wn-form" @submit.prevent="updatePassword">
      <div class="p-6 md:px-8 pb-4 border-b border-gray-100">
        <h3 class="text-lg font-semibold text-gray-900">Change Password</h3>
      </div>
      <!-- Form Fields -->
      <div class="grid p-6 md:p-8 gap-6 md:grid-cols-2">
        <input type="text" :value="viewer?.username || ''" name="username" autocomplete="username" style="display: none" />

        <div class="w-full space-y-2">
          <label for="new-password" class="block text-sm font-medium text-gray-700">{{ $t('account.newPassword') }}</label>
          <PasswordInput id="new-password" v-model="password.new" placeholder="••••••••••" type="text" required />
        </div>

        <div class="w-full space-y-2">
          <label for="new-password-confirm" class="block text-sm font-medium text-gray-700">{{ $t('account.confirmNewPassword') }}</label>
          <PasswordInput id="new-password-confirm" v-model="password.confirm" placeholder="••••••••••" type="text" required />
        </div>

        <!-- Password Requirements -->
        <div v-if="password.new" class="col-span-full p-4 bg-blue-50 border border-blue-100 rounded-lg">
          <div class="flex items-start gap-3">
            <Icon name="ion:information-circle" size="20" class="text-blue-600 shrink-0 mt-0.5" />
            <div class="text-sm text-blue-900">
              <p class="font-medium mb-2">Password requirements:</p>
              <ul class="space-y-1.5 text-blue-700">
                <li class="flex items-center gap-2">
                  <Icon
                    :name="password.new.length >= 8 ? 'ion:checkmark-circle' : 'ion:ellipse-outline'"
                    size="16"
                    :class="password.new.length >= 8 ? 'text-green-600' : 'text-gray-400'" />
                  At least 8 characters
                </li>
                <li class="flex items-center gap-2">
                  <Icon
                    :name="password.new === password.confirm && password.new ? 'ion:checkmark-circle' : 'ion:ellipse-outline'"
                    size="16"
                    :class="password.new === password.confirm && password.new ? 'text-green-600' : 'text-gray-400'" />
                  Passwords match
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Error Message -->
        <Transition name="scale-y" mode="out-in">
          <div v-if="errorMessage" class="col-span-full p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <Icon name="ion:alert-circle" size="20" class="text-red-600 shrink-0 mt-0.5" />
            <div class="text-sm text-red-800" v-html="errorMessage"></div>
          </div>
        </Transition>
      </div>

      <!-- Submit Button -->
      <div class="p-6 pt-4 flex bg-gray-50 rounded-b-lg border-t border-gray-100">
        <Button :loading="loading" type="submit" class="ml-auto" :class="button.color">
          {{ button.text }}
        </Button>
      </div>
    </form>
  </div>
</template>

<script setup lang="ts">
const { viewer, loginUser } = useAuth();
const { t } = useI18n();
const gql = useWooGraphQL();

const password = ref<{ new: string; confirm: string }>({ new: '', confirm: '' });
const loading = ref<boolean>(false);
const button = ref<{ text: string; color: string }>({ text: t('account.updatePassword'), color: 'bg-primary hover:bg-primary-dark' });
const errorMessage = ref<string>('');

const updatePassword = async () => {
  errorMessage.value = '';
  if (password.value.new !== password.value.confirm) {
    errorMessage.value = t('error.passwordMismatch');
    return;
  }

  if (!viewer.value?.id || !viewer.value?.username) {
    errorMessage.value = t('error.somethingWentWrong');
    return;
  }

  try {
    loading.value = true;
    const { updateCustomer } = await gql.UpdateCustomer({ input: { id: viewer.value.id, password: password.value.new } });
    if (updateCustomer) {
      button.value = { text: t('account.updateSuccess'), color: 'bg-green-500' };
      const { success, error } = await loginUser({ username: viewer.value.username, password: password.value.new });
      if (error) {
        errorMessage.value = error;
        button.value = { text: t('account.failed'), color: 'bg-red-500' };
      }
      if (success) {
        password.value = { new: '', confirm: '' };
      }
    }
  } catch (error) {
    console.error(error);
    const gqlError = (error as { gqlErrors?: Array<{ message?: string }> } | null)?.gqlErrors?.[0]?.message;
    errorMessage.value = gqlError || 'An error occurred. Please try again.';
    button.value = { text: t('account.failed'), color: 'bg-red-500' };
  }

  loading.value = false;

  setTimeout(() => {
    button.value = { text: t('account.updatePassword'), color: 'bg-primary hover:bg-primary-dark' };
  }, 2000);
};
</script>
